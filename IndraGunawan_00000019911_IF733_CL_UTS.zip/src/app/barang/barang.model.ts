export interface Barang{
    imageUrl: string;
    jenis: string;
    merk: string;
    model: string;
    harga: string;
    stok: string;
    baseclock: string;
    boostclock: string;
    corecount: string;
    threadcount: string;
    ukuran: string;
    speed: string;
    brand: string;
    chipset: string;
}
